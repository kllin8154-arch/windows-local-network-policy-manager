Windows Local Network Policy Manager Preview x64 - Fixed EXE

1. 解压整个 ZIP。
2. 双击 本地网络策略管理器.exe。
3. UAC 选择“是”。
4. 首次只检查界面和自动识别，不要直接点“应用全部”。
5. 验证后运行 验证预览版.cmd。

本版本修复了上一版 EXE 的 PE 结构问题。
EXE 会从自身目录启动 NetworkPolicyManager\manager.ps1。
