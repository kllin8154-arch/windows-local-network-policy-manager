Windows Local Network Policy Manager 0.2.0 Preview x64

使用方法：
1. 解压整个 ZIP。
2. 双击“本地网络策略管理器.exe”，UAC 选择“是”。
3. 第一轮先检查界面、自动识别、搜索/筛选、诊断等，不要直接点击“应用全部”。
4. 验证后双击“验证预览版.cmd”，它只做只读检查并生成 validation-result-*.zip。
5. 把生成的 ZIP 或截图返回给我。

注意：EXE 和 NetworkPolicyManager 文件夹必须保持在同一目录。
