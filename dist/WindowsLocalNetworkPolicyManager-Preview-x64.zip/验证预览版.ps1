$ErrorActionPreference='Stop'
$root=$PSScriptRoot
$manager=Join-Path $root 'NetworkPolicyManager\本地网络策略管理器.ps1'
$stamp=Get-Date -Format 'yyyyMMdd-HHmmss'
$outDir=Join-Path $root ("validation-result-"+$stamp)
New-Item -ItemType Directory -Path $outDir -Force | Out-Null
& powershell.exe -NoProfile -ExecutionPolicy Bypass -File $manager -SelfTest 2>&1 | Set-Content (Join-Path $outDir 'selftest.txt') -Encoding UTF8
& powershell.exe -NoProfile -ExecutionPolicy Bypass -File $manager -Command Discover 2>&1 | Set-Content (Join-Path $outDir 'network-discovery.json') -Encoding UTF8
& powershell.exe -NoProfile -ExecutionPolicy Bypass -File $manager -DumpStatus 2>&1 | Set-Content (Join-Path $outDir 'rule-status.json') -Encoding UTF8
& powershell.exe -NoProfile -ExecutionPolicy Bypass -File $manager -UiSmokeTest 2>&1 | Set-Content (Join-Path $outDir 'ui-test.txt') -Encoding UTF8
$png=Join-Path (Split-Path -Parent $manager) 'ui-smoke-test.png'
if(Test-Path $png){Copy-Item $png (Join-Path $outDir 'ui-smoke-test.png') -Force}
$zip=$outDir+'.zip'
Compress-Archive -Path (Join-Path $outDir '*') -DestinationPath $zip -Force
Write-Host "验证包已生成：$zip" -ForegroundColor Green
Start-Process explorer.exe -ArgumentList @('/select,',$zip)
